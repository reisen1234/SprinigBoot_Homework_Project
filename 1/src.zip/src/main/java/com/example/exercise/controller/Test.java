package com.example.exercise.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.exercise.domain.Result;
import com.example.exercise.domain.ResultType;
import com.example.exercise.pojo.TableOne;
import com.example.exercise.service.TableOneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("test")
public class Test {
    @Autowired
    private TableOneService tableOneService;
    @GetMapping("/get/id={id}")
    public Object get(@PathVariable String id){
        if(id == null){
            return new Result<TableOne>(ResultType.FAIL.getCode(), "id为空", null);
        }
        else{
            TableOne tableOne = tableOneService.getTableOne(id);
            if(tableOne == null)
                return new Result<TableOne>(ResultType.NOT_FOUND.getCode(), "404 Not Found", null);
            else {
                tableOne.setMethod("get");
                return new Result<>(ResultType.SUCCESS.getCode(), "hello world-get", tableOne);
            }
        }
    }
    @PostMapping("/post")
    public Object post( TableOne tableOne){
        if(tableOne == null){
            return new Result<TableOne>(ResultType.FAIL.getCode(), "Param error" ,null);
        }else{
            tableOne.setMethod("post");
            tableOne.setClass_("20");
            return new Result<>(ResultType.SUCCESS.getCode(), "hello world-post" ,tableOne);
        }
    }
    @PostMapping("/postJson")
    public Object postJson(@RequestBody String json){
        JSONObject jsonObject = JSON.parseObject(json);
        return "hello spring-boot:" + jsonObject.getString("username") + ":" + jsonObject.getString("password");
    }
}
