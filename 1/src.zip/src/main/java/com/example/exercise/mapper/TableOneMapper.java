package com.example.exercise.mapper;

import com.example.exercise.pojo.TableOne;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TableOneMapper {
    int addTableOne(@Param("tableOne") TableOne tableOne);
    TableOne getTableOneById(@Param("id") String id);
}
