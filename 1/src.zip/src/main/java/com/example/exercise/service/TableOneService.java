package com.example.exercise.service;

import com.example.exercise.mapper.TableOneMapper;
import com.example.exercise.pojo.TableOne;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TableOneService {
    @Autowired
    private TableOneMapper tableOneMapper;
    public int addTableOne(TableOne tableOne){return tableOneMapper.addTableOne(tableOne);}
    public TableOne getTableOne(String id){return tableOneMapper.getTableOneById(id);}
}
