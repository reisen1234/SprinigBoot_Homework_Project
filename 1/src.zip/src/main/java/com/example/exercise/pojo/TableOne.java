package com.example.exercise.pojo;

import lombok.Data;

@Data
public class TableOne {
    private String id;
    private String Class_;
    private String name;

    private String method;
    public TableOne(String id, String name) {
        this.id = id;
        this.name = name;
    }
//    public TableOne(String id, String Class_, String name) {
//        this.id = id;
//        this.Class_ = Class_;
//        this.name = name;
//    }

}
